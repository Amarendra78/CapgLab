import { Component, OnInit } from '@angular/core';
import {CustomerService } from '../service/customer.service';
import { Customer } from '../model/customer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
customers: Customer[];
  constructor(private customerService: CustomerService, private router: Router) { }

  ngOnInit() {

    this.customers = this.customerService.getAllCustomers();
  }

  update(i) {

    this.customerService.setIndex(i);
    this.router.navigate(['update'])
  }

  delete(i) {
    this.customerService.deleteCustomer(i);
  }

}
