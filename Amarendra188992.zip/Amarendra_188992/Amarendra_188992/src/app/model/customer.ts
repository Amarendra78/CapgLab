export class Customer {

    [x: string]: any;
    id:number;
    name:string;
    cost:string;
    author:string;
}
