import java.util.Arrays;

public class ArrayDemo {
	
	public static float add(float var1,int...var2)
	{
		float result=0.0f;
		for(int data:var2)
		{
			result=result+data;
		}
		result=result+var1;
		return result;
	}

	public static void main(String[] args) {
		
		int arr[]= {12,3,4,56,43};
		
		for(int var : arr)
			System.out.println(var);
		
		int arr1[]=new int[4];
		for(int j=0;j<arr1.length;j++)
            arr1[j]=j+3;
		
		System.out.println("arr1 =");
		for(int data : arr1)
			System.out.println(data);
		
		
		Arrays.sort(arr);
		System.out.println(arr);
		
//		Arrays.reverse(arr1);
		
		float res1=add(3.4f);
		float res2=add(2.4f,1);
		float res3=add(3.4f,2,3);
		float res4=add(3.4f,4,3,4);
		
		System.out.println(res1);
		System.out.println(res2);
		System.out.println(res3);
		System.out.println(res4);
	}

}
