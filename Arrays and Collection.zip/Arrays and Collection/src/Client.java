import java.util.*;

public class Client {
	public static void main(String[] args)
	{
		ArrayList<String> list=new ArrayList<String>();
		System.out.println("size ="+list.size());
		//System.out.println();
		list.add("12");//list.add(new Integer(12))
		list.add("hey");
		list.add("4.5");
		list.add("false");
		
		Iterator<String> ptr=list.iterator();
		
		while(ptr.hasNext())
			System.out.println(ptr.next());
		
		Collections.sort(list);
		for(Object obj : list)
			System.out.println(obj);
		
	}

}
