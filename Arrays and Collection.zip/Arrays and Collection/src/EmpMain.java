import java.util.*;
import java.util.Collections;

public class EmpMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Employee> list=new ArrayList<Employee>();
		list.add(new Employee(110,"suhas"));
		list.add(new Employee(109,"sneha"));
		list.add(new Employee(120,"Rekha"));
		list.add(new Employee(122,"sachin"));
		
		for(Employee emp :list)
			System.out.println(emp);
		
		Collections.sort(list);
		
		for(Employee emp :list)
			System.out.println(emp);
		
		
	}

}
