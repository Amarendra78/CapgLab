import java.util.*;

public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	LinkedHashSet<Student> stu=new LinkedHashSet<Student>();
		stu.add(new Student(5,"Rima"));
		stu.add(new Student(4,"jai"));
		stu.add(new Student(2,"Riya"));
		stu.add(new Student(2,"Riya"));
		for(Student e:stu)
			System.out.println(e);
	}

}
