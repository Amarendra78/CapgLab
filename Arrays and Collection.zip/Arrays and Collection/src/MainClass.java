import java.util.Arrays;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Student[] stu=new Student[3];
//System.out.println("name = "+stu[1].getsName());
stu[0]=new Student(12,"Abha");
stu[1]=new Student(13,"Abhi");
stu[2]=new Student(122,"Abhay");

for(Student ele : stu)
	System.out.println(ele);
for(int i=0;i<3;i++)
{
for(int j=0;j<3;j++)
{
	if(stu[i].rollNo>stu[j].rollNo)
	{
		Student tmp=stu[i];
		stu[i]=stu[j];
		stu[j]=tmp;
	}
}
}

//Arrays.sort(stu);
for(Student ele : stu)
	System.out.println(ele);
		
	}

}
