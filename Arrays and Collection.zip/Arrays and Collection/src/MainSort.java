import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class MainSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Student> list=new ArrayList<Student>();
		list.add(new Student(45,"Akash"));
		list.add(new Student(5,"sima"));
		list.add(new Student(14,"Reena"));
		list.add(new Student(9,"Karan"));
		
		
		for(Student emp :list)
			System.out.println(emp);
		
		
	//	Collections.sort(list);
		Collections.sort(list, new SortObject());
		Collections.sort(list, new SortObject());
System.out.println("list after sorting");
		for(Student emp :list)
			System.out.println(emp);
		
	
	}

}
