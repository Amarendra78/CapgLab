import java.util.ArrayList;
import java.util.Collections;

public class MainStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<Student>list=new ArrayList<Student>();
list.add(new Student(23,"Riya"));
list.add(new Student(233,"Ria"));
list.add(new Student(223,"Rya"));
list.add(new Student(213,"iya"));

for(Student e:list)
	System.out.println(e);

      // Collections.sort(list);
	System.out.println("list has "+list.contains(new Student(23,"Riya")));
	}

}
