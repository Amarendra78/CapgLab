import java.util.*;
public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
LinkedHashMap<Integer,Employee> map=new LinkedHashMap<Integer,Employee>();
Employee emp1=new Employee(110,"Alphy");
Employee emp2=new Employee(120,"Ganesh");
Employee emp3=new Employee(115,"Amit");


map.put(emp1.getEmpId(),emp1);

map.put(emp2.getEmpId(),emp2);

map.put(emp3.getEmpId(),emp3);


Employee e=map.get(115);
System.out.println(e);
//map.put(null,new Employee(111,"Amrit"));

//Set<Integer> keys=map.keySet();

/**
for(Integer key :keys)
{
System.out.println("key ="+key);
System.out.println("value ="+map.get(key));
}

System.out.println("Entry set output ::");
System.out.println(map.entrySet());
**/
//System.out.println("map="+map);
	}

}
