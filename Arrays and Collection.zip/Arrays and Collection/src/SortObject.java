import java.util.*;
public class SortObject implements Comparator<Object> {

	@Override
	public int compare(Object arg0,Object arg1)
	{
		int diff=0;
		if(arg0 instanceof Employee && arg1 instanceof Employee)
		{
			Employee emp1=(Employee)arg0;
			Employee emp2=(Employee)arg1;
			
			diff=emp1.getEmpId()-emp2.getEmpId();
			
		}
		else if(arg0 instanceof Student && arg1 instanceof Student)
		{
			Student stu1=(Student)arg0;
			Student stu2=(Student)arg1;
			
			diff=stu1.getRollNo()-stu2.getRollNo();
			
		}
		return diff;
	}
}
