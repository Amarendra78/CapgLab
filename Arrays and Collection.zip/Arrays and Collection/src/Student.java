import java.util.*;
public class Student{// implements Comparable<Student> {
	
	int rollNo;
	String sName;
	public Student(int rollNo, String sName) {
		super();
		this.rollNo = rollNo;
		this.sName = sName;
	}
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", sName=" + sName + "]";
	}
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
/**	
	@Override
	public int hashCode()
	{
		return this.sName.length();
	}
	
	@Override
	public boolean equals(Object obj)
	{
		boolean flag=false;
		if(obj instanceof Student) {
			
		Student stu=(Student)obj;
		if(this.rollNo==stu.rollNo && this.sName.equals(stu.sName))
			flag=true;
		//return flag;
		
	}
		return flag;
}**/
	//@Override
/**	
	public int compareTo(Student o)
	{
		return this.rollNo - o.rollNo;
		
	}
	**/
	
}