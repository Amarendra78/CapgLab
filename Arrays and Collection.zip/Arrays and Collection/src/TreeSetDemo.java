import java.util.*;

public class TreeSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeSet<String> stu=new TreeSet<String>();
		stu.add("Rima");
		stu.add("jai");
		stu.add("Riya");
		stu.add("Riya");
		
		for(String e:stu)
			System.out.println(e);
	}
		
	}


