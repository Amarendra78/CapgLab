import java.util.*;
public class VectorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Vector v=new Vector();
int size=v.size();
int cap=v.capacity();

System.out.println("size = "+size);
System.out.println("capacity = "+cap);


Vector v2=new Vector(3,4);
int size1=v2.size();
int cap1=v2.capacity();

System.out.println(" new size = "+size1);
System.out.println(" new capacity = "+cap1);

	}

}
