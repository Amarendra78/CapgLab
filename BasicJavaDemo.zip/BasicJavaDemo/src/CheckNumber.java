class Nature
{
	
int num;

public String nature(int num1)
{
num=num1;
if(num<0)
	return "negative" ;
else
	return "positive";

}

}
public class CheckNumber {

	public static void main(String...args) {
		Nature n1=new Nature();
		int num=Integer.parseInt(args[0]);
		String ans=n1.nature(num);
		System.out.println(ans);

	}

}
