
public abstract class Employee {
	
	
	
	private int empId;
	private String empName;
	private static int count=0;
	int empSal;
	
	public abstract int calsal();
	
	private Employee(int empId,String empName)
	{
		super();
		this.empId=empId;
		this.empName=empName;
		count++;
	}
	
	public Employee()
	{
		
		
	}
	/**
	public Employee createObject()
	{
		Employee emp;
		//Employee emp=null;
		//Object Employee;
		if(count==0)
	 emp=new Employee(112,"Hellowen");
	
		return emp;
	}**/
	
	public int getEmpSal()
	{
		return this.empId;
	}
	
	public void setEmpSal(int empSal)
	{
	 this.empSal=empSal;
	}
	

	public int getEmpId()
	{
		return this.empId;
	}
	
	public String getEmpName()
	{
		return this.empName;
	}
	
	public void setEmpId(int empId)
	{
		this.empId=empId;
	}
	public void setEmpName(String empName)
	{
		this.empName=empName;
	}
	
	public static int showCount()
	{
		return count;
	        //	System.out.println(this.empName);
	}
	
}
