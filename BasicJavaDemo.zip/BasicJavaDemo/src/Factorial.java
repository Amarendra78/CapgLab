class Number
{
	int n1;
public int fact(int n)
{
	n1=n;
	int mul=1;
	for(int i=n1;i>=1;i--)
	{
		mul=mul*i;
		
	}
return mul;
}

}
public class Factorial {

	public static void main(String[] args)
	{
Number n1=new Number();
int num=Integer.parseInt(args[0]);
System.out.println("factorial of number is "+n1.fact(num));
	}

}
