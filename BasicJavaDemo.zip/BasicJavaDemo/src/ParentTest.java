
 abstract class ParentTest {
	int a;
   
	abstract public void  fun1();
	
	   void fun2()
	 {
		
	}
	
}
