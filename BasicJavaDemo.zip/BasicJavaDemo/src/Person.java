class Details
{
	
String fname;
String lname;
String gender;
int age;
double weight;

public void detail(String fname1,String lname1,String gender1,int age1,double weight1)
{
	fname = fname1;
			lname=lname1;
			gender=gender1;
			age=age1;
			weight=weight1;
System.out.println("First name :"+fname);
System.out.println("Last name :"+lname);
System.out.println("Gender :"+gender);
System.out.println("Age :"+age);
System.out.println("Weight :"+weight);


}

}



public class Person{

	public static void main(String[] args) {
		Details d=new Details();
     d.detail("Amarendra","singh","M",23,67.78);
	}

}
