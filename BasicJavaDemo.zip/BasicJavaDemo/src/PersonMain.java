class Person1
{
String fname;
String lname;
char c;

public Person1(String fname1,String lname1,char c1)
{
fname=fname1;
lname=lname1;
c=c1;
	
}

public String get()
{
return("First name :"+fname  +"\n"+"Lastname : "+lname+"\n"+"Gender :"+c);
}

}
public class PersonMain {

	public static void main(String[] args) {
		Person1 p1=new Person1("Amarendra","Singh",'M');
		String ans=p1.get();
		System.out.println(ans);

	}
	

}
