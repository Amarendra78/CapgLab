class Person2
{
String fname;
String lname;
char c;
int age;
double weight;

public Person2(String fname1,String lname1,char c1,int age1,double weight1)
{
fname=fname1;
lname=lname1;
c=c1;
age=age1;
weight=weight1;
	
}

public String toString()
{
return("First name :"+fname  +"\n"+"Lastname : "+lname+"\n"+"Gender :"+c+"\n"+"Age :"+age  +"\n"+"Weight :"+weight);
}

}
public class PersonMain1{

	public static void main(String[] args) {
		Person2 p1=new Person2("Amarendra","Singh",'M',23,67.87);
		//String ans=p1.get();
		System.out.println(p1);

	}
	

}
