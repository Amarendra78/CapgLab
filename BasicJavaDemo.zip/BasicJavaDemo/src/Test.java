
public class Test extends ParentTest {
	
	public void fun1()
	{
		System.out.println("Hello oveeriden function");
	}

	public void fun2()
	{
		System.out.println("Hello oveeriden function");
	}
	
	public Test() {
		super();
		// TODO Auto-generated constructor stub
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	
}
