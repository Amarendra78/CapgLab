class Calculator{
	
	int num1;
	int num2;
	
	public int add(int number1,int number2)
	{
		num1=number1;
		num2=number2;
		return (num1+num2);
	}
			
			
	
	
}
public class TestCalculatorDemo {

	public static void main(String[] args) 
	{
		Calculator calc1=new Calculator();
		System.out.println("Addition of  number"+calc1.add(70,80));

	}

}
