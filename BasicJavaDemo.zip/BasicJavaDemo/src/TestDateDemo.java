
public class TestDateDemo {

	public static void main(String[] args)
	{
		Date ramdoj=new Date();
		ramdoj.setDate(11,07,2019);

		Date vaishalidoj=new Date();
		vaishalidoj.setDate(03,04,2010);
		
		System.out.println("ram date of joining "+ramdoj.dispDate());
		System.out.println("Mentors date of joining "+vaishalidoj.dispDate());
	}

}
