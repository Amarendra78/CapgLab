package com.cg.classlibrary;
//package com.cg.classlibrary;
public class Student {
	
	int roll;
	String name;
	
	public int hashCode()
	{
		return name.length() + 5;
		
	}
	
	public boolean equals(Object obj)
	{
		boolean flag=false;
		if(obj instanceof Student)
		{
			Student stu=(Student)obj;
			if(stu.roll==this.roll&&stu.name.equals(this.name))
			flag=true;
		}
		return flag;
	}
	
	
	@Override
	public String toString() {
		return "Student [roll=" + roll + ", name=" + name + "]";
	}
	
	public void finalize()
	{
		
	  }

	public int getRollNo()
	{
		return roll;
	}

	public void setRollNo(int roll)
	{
		this.roll=roll;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name=name;
	}
	
	public Student(int roll,String name)
	{
		this.roll=roll;
		this.name=name;
		
	}

}
