package snippet;

public class Snippet {
	public void getRollNo()
	{
		//return roll;
	}
	
}

