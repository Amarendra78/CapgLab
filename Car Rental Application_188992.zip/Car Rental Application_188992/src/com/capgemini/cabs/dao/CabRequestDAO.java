package com.capgemini.cabs.dao;

import java.sql.*;
import com.capgemini.cabs.dto.CabRequest;
import com.capgemini.cabs.exception.MyException;
import com.capgemini.cabs.log4j.Logg;
import com.capgemini.cabs.util.DBUtil;
import com.capgemini.cabs.util.MyStringDateUtil;


import org.apache.log4j.Logger;
public class CabRequestDAO implements ICabRequestDAO{
	
	
	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet re = null;
	static Logger calcLogger=null;

	public CabRequestDAO()
	{
		calcLogger=Logg.fun(this.getClass());
		}
	@Override
	public int addCabRequestDetails(CabRequest cr) throws MyException {
		
		con = DBUtil.getCon();
		java.sql.Date sqlDOB = MyStringDateUtil.fromLocalToSqlDate(cr.getDate_of_request());
		
		int dataInserted = 0;
		
		try {
			pst = con.prepareStatement(QueryMapper.CAB_INSERT_QRY);											
					pst.setString(1, cr.getCustomer_name());
					pst.setString(2, cr.getPhone_number());
					pst.setDate(3, sqlDOB);
					pst.setString(4, "Pending");
					pst.setString(5, "MH VS"+cr.getCab_number());
					pst.setString(6, cr.getAddress_of_pickup());
					pst.setString(7,cr.getPincode());
					dataInserted = pst.executeUpdate();

					if (dataInserted != 0) {
						System.out.print("Request has been succesfully regidtered: your id is :");
						pst = con.prepareStatement(QueryMapper.CAB_SELECT);
						pst.setString(1, cr.getPhone_number());
						re = pst.executeQuery();
						if (re.next()) {
							int num = re.getInt(1);
						System.out.print(num);
						}						
					} else
						System.out.println("data Not updated in mobile table");

				}
			 catch (Exception e) {
			calcLogger.warn("In Exception");	
			throw new MyException(e.getMessage());
		}
		return dataInserted;
		
		
		
	}

	@Override
	public void CabRequestgetRequestDetails(int requestId) throws MyException {
		// TODO Auto-generated method stub
		try {
			pst = con.prepareStatement(QueryMapper.CAB_BY_ID);
			pst.setInt(1, requestId);
			re = pst.executeQuery();
			if (re.next()) {
				
			
				String name = re.getString("customer_name");
				String status = re.getString("request_status");
				String num = re.getString("cab_number");
				String address = re.getString("address_of_pickup");

				System.out.println("NAME : "+name + " \n" +"STATUS :"+ status + "\n "+"CAB_NUMBER :" + num + "\n " +"ADDRESS :"+ address);
			
				}}
			 catch (Exception e) {
			calcLogger.error("In Exception");	
			throw new MyException(e.getMessage());
		}
		
	
		

}}
