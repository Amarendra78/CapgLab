package com.capgemini.cabs.dao;

import com.capgemini.cabs.dto.CabRequest;
import com.capgemini.cabs.exception.MyException;

public interface ICabRequestDAO {
	
	
	public int addCabRequestDetails(CabRequest cr)throws MyException;
	public void CabRequestgetRequestDetails(int requestId)throws MyException;

}
