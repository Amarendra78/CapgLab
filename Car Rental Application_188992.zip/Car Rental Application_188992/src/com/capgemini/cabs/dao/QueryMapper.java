package com.capgemini.cabs.dao;

public interface QueryMapper {
	  
	
	
	public static final String CAB_INSERT_QRY="INSERT into cab_request VALUES(seq_request_id.nextval,?,?,?,?,?,?,?)";
	
	public static final String CAB_SELECT="SELECT request_id FROM cab_request WHERE phone_number=?";
	
	public static final String CAB_BY_ID="SELECT customer_name,request_status,cab_number,address_of_pickup FROM cab_request WHERE request_id=?";
	

}
