package com.capgemini.cabs.log4j;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

 public class Logg {

	 
	
	public static Logger fun(Class s)
	{
		Logger calLogger =null;
	calLogger=Logger.getLogger(s);
	PropertyConfigurator.configure("log4j.properties");
	
	return calLogger;
}
}