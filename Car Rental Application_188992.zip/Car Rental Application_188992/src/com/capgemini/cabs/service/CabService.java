package com.capgemini.cabs.service;
import java.util.regex.Pattern;
import com.capgemini.cabs.dao.CabRequestDAO;
import com.capgemini.cabs.dto.CabRequest;
import com.capgemini.cabs.exception.MyException;


public class CabService implements ICabService{
	
	
	CabRequestDAO perDao=null;
	public CabService()
	{
		perDao=new CabRequestDAO();
	}
	
	
	public int addCabRequestDetails(CabRequest cr)throws MyException {
		// TODO Auto-generated method stub
		int a=	perDao.addCabRequestDetails(cr);
				return a;
	}

	public void CabRequestgetRequestDetails(int requestId)throws MyException{
		// TODO Auto-generated method stub
		perDao.CabRequestgetRequestDetails(requestId);
	}
	
	

	public boolean validateName(String name)throws MyException {
		
		String empNamePattern="[A-Z]{1}[a-z]{2,10}";
		if(Pattern.matches(empNamePattern,name))
		return true;
		else
					throw new MyException("Invalid name "+"should start with capital ");
	}

	public boolean validatePhoneNumber(String phone)throws MyException {
		
		String empNamePattern="[7-9]{1}[0-9]{9}";
		if(Pattern.matches(empNamePattern,phone))
		return true;
		else
					throw new MyException("Invalid phone "+"should start with 7,8,9 and of 10 digit only");	
	}

	public boolean validatePincode(String pin)throws MyException {
		if(pin.equals("40096")||pin.equals("411026")||pin.equals("411013")||pin.equals("560066")||pin.equals("382009")||pin.equals("400708"))
		{
		String empNamePattern="[0-9]{6}";
		if(Pattern.matches(empNamePattern,pin))
		return true;
		else
					throw new MyException("Invalid pin "+"must be of 6 digits only");	
	}
		else {
	System.out.println("Invalid pin number");
		throw new MyException("Invalid pin "+"must be of 6 digits only");			
	}}

	

	

	

}
