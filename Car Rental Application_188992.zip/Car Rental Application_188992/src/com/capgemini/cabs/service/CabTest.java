package com.capgemini.cabs.service;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

import com.capgemini.cabs.dto.CabRequest;

import org.junit.*;
import junit.*;
import junit.framework.Assert;

public class CabTest {

static CabRequest cab=null;
	@BeforeClass
	public static void setup()
	{
		cab=new CabRequest();
		System.out.println("Will run first");
	}

@Before
public void init()
{
System.out.println("this is called once before exe of calculator");	
}
/**
@Test
public void squaredTest1()
{
	Assert.assertEquals(true,cab.validateName("Aman"));

}

@Test
public void squaredTest2()
{
	Assert.assertEquals(1,calc.squared(1));

}
@Test
public void squaredTest3()
{
	Assert.assertEquals(10,calc.squared(-1));

}

@Test
public void divideTest1()
{
	Assert.assertEquals(10,calc.divide(10));

}

@Ignore
public void divideTest2()
{
	Assert.assertEquals(10,calc.divide(100));

}

@Test(expected=MyException.class)
public void divideTest3()
{
	Assert.assertEquals(true,cab.validateName());

}

**/

@Ignore
public void divideTest2()
{
	//Assert.assertEquals(10,cab.divide(100));

}
	@AfterClass
	public static void tearDown()
	{
		System.out.println("After the execution of each test Cases");
	}
	@After
	public void destroy()
	{
		
		System.out.println("After exe of all test case");
	}

}
