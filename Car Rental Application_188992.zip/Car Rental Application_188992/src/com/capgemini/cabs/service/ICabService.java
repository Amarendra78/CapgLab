package com.capgemini.cabs.service;
import com.capgemini.cabs.dto.CabRequest;
import com.capgemini.cabs.exception.MyException;


public interface ICabService {
	
	public int addCabRequestDetails(CabRequest cr)throws MyException;
	public void CabRequestgetRequestDetails(int requestId)throws MyException;
	
	
	public boolean validateName(String name)throws MyException;	
	public boolean validatePhoneNumber(String phone)throws MyException;
	public boolean validatePincode(String pin)throws MyException;
	

}
