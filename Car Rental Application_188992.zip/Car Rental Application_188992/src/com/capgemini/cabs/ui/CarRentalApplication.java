package com.capgemini.cabs.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.cabs.dto.CabRequest;
import com.capgemini.cabs.exception.MyException;
import com.capgemini.cabs.service.CabService;




public class CarRentalApplication {

	static Scanner sc=null;
	 static CabService cb=null;
	 static CabRequest cabRequest=null;
	public static void main(String[] args) {
		

		 sc=new Scanner(System.in);
	       	cb=new CabService();
		while(true)
		{

			
			System.out.println("............... you can perform following activities...........");
			System.out.println(" 1. Raise Cab Request");
		  	System.out.println(" 2. View Cab Request Status");
			System.out.println(" 3. Exit");
			
			System.out.println("Enter your choice.....");
			
			int choice=sc.nextInt();
		switch(choice)
		{
		
		case 1:
			addCabRequestDetails();
			break;			
     case 2:
    	 System.out.println("Enter RequestId");
    	 int requestId=sc.nextInt();
	        CabRequestgetRequestDetails(requestId);
	        break;
		
     case 3:
    	 System.out.println("Exit");
    	 System.exit(0);     	
    
		default:
			System.exit(0);		
			
		  }
		
		}
		
	}
	
	
	
	private static void addCabRequestDetails()
	{
	System.out.println("Enter details Regarding Booking of cab");
	
	System.out.println("Enter name of the Customer :");
	String name=sc.next();
    try {
    	if(cb.validateName(name))
    	{
			System.out.println("Enter customer Phone Number: ");
	        String phone=sc.next();
	        if(cb.validatePhoneNumber(phone))
        	{
	        	System.out.println("Enter pickup Address : ");
		        String address=sc.next();
	        	      	
	        	System.out.println("Enter Pincode : ");
	        	String pin=sc.next();
			if(cb.validatePincode(pin))
        	{
				
				LocalDate date = LocalDate.now();
	        
	        CabRequest cr =new CabRequest(name,phone,date,address,pin);
	        
	        int c=cb.addCabRequestDetails(cr);
	        
        	     }
			
        	   }
	          }
			    	  
    	      } catch(Exception ee) {
    	           System.out.println(ee.getMessage());
             }
		
			}
	
	private static void CabRequestgetRequestDetails(int requestId) {
		
		try {
			cb.CabRequestgetRequestDetails(requestId);
		} catch (MyException e) {
			
			e.printStackTrace();
		}
	}
	
	


}
