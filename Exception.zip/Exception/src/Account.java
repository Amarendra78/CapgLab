
public class Account {
	
	static int accountNumber=100;
	int balance;
	String name;
	public Account(int balance, String name) {
	//	super();
		this.balance = balance;
		this.name = name;
	}
	
	public void withdraw(int amt)throws AccountException
	{
		
		//try {
			if(amt > balance)
			{
				throw new AccountException("no balance");
			}
			else
				balance=balance-amt;
		}//catch(Exception e) {
     // System.out.println(e.getMessage()); 
//	}}
	public void deposite(int amt)
	{
		balance=balance+amt;
	}
	
	public int getBalance()
	{
		return this.balance;
	}

}
