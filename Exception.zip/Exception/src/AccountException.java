
public class AccountException extends Exception{
	String message;
	
	public AccountException(String message)
	{
		this.message=message;
	}

	public String getMessage()
	{
		return this.message;
	}
}
