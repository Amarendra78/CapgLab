
public class CreateAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//Account obj1= new Account(5000,"gita");
//System.out.println(obj1.getBalance());
//try {
//obj1.withdraw(2000);
//obj1.withdraw(3000);
//obj1.withdraw(3000);
//}
//catch(AccountException e)
//{
//System.out.println(e.getMessage());
//}
//System.out.println(obj1.getBalance());
//	}
		DivisionDemo d=new DivisionDemo();
		try {
		    d.divisionDemo();	
		}
		catch(ArithmeticException e)
		{
		System.out.println(e.getMessage()+"Hello");
		}}
		

}
