import java.util.Scanner;

public class DivisionDemo {

	
	void divisionDemo() throws ArithmeticException{	
		try(Scanner sc=new Scanner(System.in)){
		System.out.println("Enter no =");
		int num=sc.nextInt();
		System.out.println("Enter Den :: ");
		int den=sc.nextInt();
	//	String str=null;
		int result=0;
		if(den==0)
		   throw new ArithmeticException();
		else {
		 result=num/den;
		System.out.println(result);
		}
		/**	}catch(ArithmeticException e) {
			System.out.println(e.getMessage());
			//System.out.println(result);
		}catch(Exception e1) {
			System.out.println(e1.getMessage());
			//System.out.println(result);
		}		
		finally {
			System.out.println("finally");
		}**/
		
}
	}

}
