package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hoteldetails")
public class Hotel {
	@Id
	@Column(name = "id", length = 15)
	private int hotelId;
	
	@Column(name = "name", length = 15)
	private String hotelName;
	
	@Column(name = "rating", length = 15)
	private String rating;
	
	@Column(name = "rate", length = 15)
	private int hotelrate;
	
	@Column(name = "availablerooms", length = 15)
	private int availablerooms;
	
	
	
	public Hotel() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ", hotelrate=" + hotelrate
				+ ", availablerooms=" + availablerooms + ", rating=" + rating + "]";
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public int getHotelrate() {
		return hotelrate;
	}

	public void setHotelrate(int hotelrate) {
		this.hotelrate = hotelrate;
	}

	public int getAvailablerooms() {
		return availablerooms;
	}

	public void setAvailablerooms(int availablerooms) {
		this.availablerooms = availablerooms;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	
	
}