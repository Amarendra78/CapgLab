package com.cg.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


import com.cg.bean.Hotel;
import com.cg.service.IServiceClass;

@Controller
public class LoginController {
	@Autowired
	IServiceClass service;

	public IServiceClass getService() {
		return service;
	}

	public void setService(IServiceClass service) {
		this.service = service;
	}

	@RequestMapping("/Homedetailspage")
	public String retrieveHotels(Model model) {
		ArrayList<Hotel> hotels = service.getHotels();
		model.addAttribute("hotels", hotels);
		return "HomeDetails";
	}
	@RequestMapping("/RetreiveTrainee")
	public String retreiveTrainee() 
	{   
		return "HotelBookingSuccessPage";
	}
	
	

	

	
}
