package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;


import com.cg.bean.Hotel;

@Repository
@Transactional
public class DaoClass implements IDaoClass {

	@PersistenceContext
	EntityManager em;

	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}

	

	@Override
	public ArrayList<Hotel> getHotels() {
		ArrayList<Hotel> list = (ArrayList<Hotel>) em.createQuery("from Hotel", Hotel.class).getResultList();
		return list;
	}

	@Override
	public Hotel getHotel(Hotel hotel) {
		return em.find(Hotel.class, hotel.getHotelName());
	}

	

}
