package com.cg.dao;

import java.util.ArrayList;


import com.cg.bean.Hotel;

public interface IDaoClass {
	

	Hotel getHotel(Hotel trainee);
	public ArrayList<Hotel> getHotels();
}
