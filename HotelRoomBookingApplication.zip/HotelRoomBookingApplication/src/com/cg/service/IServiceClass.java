package com.cg.service;

import java.util.ArrayList;


import com.cg.bean.Hotel;

public interface IServiceClass {

	
	Hotel getHotel(Hotel string);
	ArrayList<Hotel> getHotels();
}
