package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.bean.Hotel;
import com.cg.dao.IDaoClass;

@Service
public class ServiceClass implements IServiceClass {

	@Autowired
	IDaoClass dao;

	public IDaoClass getDao() {
		return dao;
	}

	public void setDao(IDaoClass dao) {
		this.dao = dao;
	}

	
	@Override
	public ArrayList<Hotel> getHotels() {
		return dao.getHotels();
	}

	

	@Override
	public Hotel getHotel(Hotel trainee) {
		return dao.getHotel(trainee);
	}
}
