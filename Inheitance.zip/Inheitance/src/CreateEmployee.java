
public class CreateEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee emp=new Employee(101,"Atul",50000);
		WageEmp wEmp=new WageEmp(102,"Raj",60000,200,300);
		
		System.out.println("emp = "+emp);
		System.out.println("wEmp = "+wEmp);

	}

}
