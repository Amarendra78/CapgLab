
public class SalesPerson extends WageEmp{

	int sales,comission;
	
	

	public int getSales() {
		return sales;
	}

	public void setSales(int sales) {
		this.sales = sales;
	}

	public int getComission() {
		return comission;
	}

	public void setComission(int comission) {
		this.comission = comission;
	}

	public SalesPerson() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SalesPerson(int empId, String empName, int empSal, int hour, int rates,int sales,int comission) {
		super(empId, empName, empSal, hour, rates);
		// TODO Auto-generated constructor stub
		this.sales=sales;
		this.comission=comission;
	}

	

}
