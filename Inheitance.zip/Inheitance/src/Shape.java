
public abstract class Shape {

	public abstract double calArea();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Shape t=new Traingle(10,10);
Shape r=new Rectangle(5,5);
Shape c=new Circle(10);

System.out.println(t.calArea());
System.out.println(r.calArea());
System.out.println(c.calArea());
	}

}
