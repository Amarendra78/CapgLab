
public class Traingle extends Shape {
	int base,height;

	public int getBase() {
		return base;
	}

	public void setBase(int base) {
		this.base = base;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	@Override
	public String toString() {
		return "Traingle [base=" + base + ", height=" + height + "]";
	}

	public Traingle() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Traingle(int base, int height) {
		super();
		this.base = base;
		this.height = height;
	}
	
	public double calArea()
	{
		return (0.5)*base*height;
	}

}
