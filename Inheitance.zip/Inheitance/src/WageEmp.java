
public class WageEmp extends Employee {

	int hour,rate;

	public WageEmp() {
		super();
		// TODO Auto-generated constructor stub
		hour=rate=0;
	}

	public WageEmp(int empId, String empName,int empSal,int hour,int rates) {
		super(empId, empName, empSal);
		// TODO Auto-generated constructor stub
		this.hour=hour;
		this.rate=rates;
	}
	
	public int calsal()
	{
	return hour*rate;
	}

	public int getHour() {
		return hour;
	}

	public void setHour(int hour) {
		this.hour = hour;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	@Override
	public String toString() {
		return "WageEmp [hour=" + hour + ", rate=" + rate + "]";
	}

	

	
	
	
}
