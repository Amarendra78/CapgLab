import java.io.*;
//import java.util.Scanner;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		FileInputStream fis=new FileInputStream("Empdata.txt");
		DataInputStream dos=new DataInputStream(fis);
		
		int data=dos.read();
		while(data!=-1) {
	
			System.out.print((char)data);
			data=dos.read();
			}
		}catch(IOException e) {
			
			e.printStackTrace();
		}
		
		
            
	}

}



