import java.io.EOFException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.*;
public class TestDeserializationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
FileInputStream fis=new FileInputStream("EmpInfo.obj");
ObjectInputStream ois=new ObjectInputStream(fis);

               Emp e=(Emp)ois.readObject();
               while(e!=null)
               {
            	   try {
		System.out.println(" Emp read from file="+e);
               e=(Emp)ois.readObject();
            	   }catch(EOFException e1)
            	   {
            	   	break;
            	   	}
               }

               }catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
