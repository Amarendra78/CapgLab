import java.io.*;
import java.util.Scanner;

public class TestEmpDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		FileOutputStream fos=new FileOutputStream("Empdata.txt");
		DataOutputStream dos=new DataOutputStream(fos);
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Emp Id:");
		int eId=sc.nextInt();
		
		System.out.println("Enter Emp name:");
		String eNm=sc.next();

		
		System.out.println("Enter Emp Salary:");
		float eSal=sc.nextFloat();
		
		dos.writeInt(eId);
		dos.writeUTF(eNm);
		dos.writeFloat(eSal);
		System.out.println("All emp data "+"Written Succesfully");

		}catch(IOException e) {
			
			e.printStackTrace();
		}
		
		
            
	}

}
