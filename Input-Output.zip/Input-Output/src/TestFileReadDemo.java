import java.io.*;
public class TestFileReadDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
File myfile=new File("D:/shru_lab/Lab2EServletWS/BasicJavaDemo/src/B.java");
	try {
		
		FileReader fr=new FileReader(myfile);                  //line by line
		BufferedReader br=new BufferedReader(fr);
		
		FileWriter fw=new FileWriter("xyz.txt");
		BufferedWriter bw=new BufferedWriter(fw);
		
		
		String data=br.readLine();
		while(data!=null) {
			
			bw.write(data);
			bw.newLine();
			bw.flush();
			System.out.print(data);
			data=br.readLine();
		}
		
/**	FileInputStream fis=new FileInputStream(myfile);
	FileOutputStream fos=new FileOutputStream("abc.txt");
	int data=fis.read();                                         //byte by byte
	while(data!=-1) {
		
		System.out.print((char)data);
		fos.write(data);
		data=fis.read();
	}
	System.out.println("Data is written on the file ");
	**/
	}catch(IOException e)
	{
		e.printStackTrace();
		
	}
	
	
	}

}
