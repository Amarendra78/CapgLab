import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

public class TestPropFileDemo {

	public static <E> void main(String[] args) {
		// TODO Auto-generated method stub
FileReader fr;
try {
	fr = new FileReader("UserInfo.properties");
	Properties myProps=new Properties();
	myProps.load(fr);
	
	Enumeration myEnum=myProps.keys();
	
	while(myEnum.hasMoreElements())
	{
		String propName=(String)myEnum.nextElement();
		System.out.println(myProps.getProperty(propName));
	}
	
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


	}

}
