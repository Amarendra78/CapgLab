import java.io.*;
import java.util.Properties;

public class TestPropWriteDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			FileWriter fw=new FileWriter("CompInfo.properties");
			Properties cgProps=new Properties();
			cgProps.setProperty("compName","capgemini");
			cgProps.setProperty("compLOC","Pune");
			cgProps.store(fw,"file contains company info");
			System.out.println("Props written in file... ");
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}

}
