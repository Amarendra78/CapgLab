import java.io.*;
public class TestReadDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	String empName;
	int empId;
	float empSal;
	InputStreamReader isr=null;
	BufferedReader br=null;
		try {
		isr=new InputStreamReader(System.in);
		br=new BufferedReader(isr);
		
		
		System.out.println("Enter your Id:");
		empId=Integer.parseInt(br.readLine());
		
		System.out.println("Enter your name:");
		empName=br.readLine();
		
		System.out.println("Enter your Salary:");
		empSal=Float.parseFloat(br.readLine());
			
		System.out.println(empId+" "+empName+" "+empSal);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//
		//System.out
	}

}
