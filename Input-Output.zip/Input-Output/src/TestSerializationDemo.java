import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.*;
public class TestSerializationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
try {
FileOutputStream fos=new FileOutputStream("EmpInfo.obj");
ObjectOutputStream oos=new ObjectOutputStream(fos);	
int i=1;
int n=sc.nextInt();
while(i<=n)
{
System.out.println("Enter empId for Employee "+i);
int eId=sc.nextInt();

System.out.println("Enter empName of Employee "+i);

String enm=sc.next();

System.out.println("Enter empSal of Employee "+i);
float esal=sc.nextFloat();

Emp e1=new Emp(eId,enm,esal);
oos.writeObject(e1);
System.out.println("obj written...");
i++;
}
}catch(IOException e)
{
	e.printStackTrace();
	}

sc.close();
}

}
