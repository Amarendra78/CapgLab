package com.capgemini.lesson5;

class DefaultDemo {
	public static void main(String a[]) {
		String str = null;
		str.equals("Hello");
	}
}
