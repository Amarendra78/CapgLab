package com.capgemini.lesson5;

	 class StringFinally extends Exception 
	{
		private int detail;
		private String args;
		StringFinally(int a) {
	        detail = a;
	     }
		StringFinally(String args) {
			this.args=args;
		 }
	     public String toString()      {
	        return "StringFinally["+args+"]";
	     }
	}
	class UserException1 {
	     static void compute(String a) throws StringFinally {
		     System.out.println("called compute("+a+")");
			 if (a=="a")
				throw new StringFinally(a);
		     System.out.println("Normal Exit");
	     }

		public static void main(String arg[]) {
			try {
				compute("h");
				compute("a");
			} catch (StringFinally e) {
				System.out.println("caught  "+e);
	        }
		}  
	}


