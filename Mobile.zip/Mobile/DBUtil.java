package com.cg.mobile.util;

import java.util.*;
import java.io.*;
import java.sql.*;
import com.cg.mobile.exception.*;
import com.cg.mobile.exception.MobileException;
public class DBUtil {

	static String unm;
	static String pwd;
	static String url;
	static String driver;
	
	public static Connection getCon()throws MobileException
	{
		Connection con=null;
		try {
		Properties dbProps=DBUtil.getDBInfo();
		unm=dbProps.getProperty("dbUserName");
		pwd=dbProps.getProperty("dbPassword");
		url=dbProps.getProperty("dburl");
		driver=dbProps.getProperty("dbdriver");
		
		Class.forName(driver);
		
		con=DriverManager.getConnection(url,unm,pwd);
		}catch(Exception ee)
		{
			throw new MobileException(ee.getMessage());
		}
		
		return con;
		
	}
	
	
	
	public static Properties getDBInfo() throws IOException
	{
		FileReader fr=new FileReader("dbinfo.properties");
		
		
		Properties myProps=new Properties();
		myProps.load(fr);
		return myProps;
	}
}
