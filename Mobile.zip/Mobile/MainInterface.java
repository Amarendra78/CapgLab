package com.cg.mobile.ui;

import java.util.Scanner;

//import com.cg.ems.dto.Employee;
import com.cg.mobile.util.MyStringDateUtil;
import com.cg.mobile.exception.MobileException;
import com.cg.mobile.service.*;
import com.cg.mobile.service.PerchaseDetail;

public class MainInterface {

	static PerchaseDetailImpl perchase=null;
	public static void main(String[] args) {
		
	 Scanner sc=new Scanner(System.in);
		perchase=new PerchaseDetailImpl();
		while(true)
		{
			System.out.println("...............Functionality you can perform...........");
			System.out.println(" 1. Insert the customer and purchase details into database");
		    System.out.println(" 2. Update the mobile quantity in mobiles table, once mobile is purchased by a customer.");
			System.out.println(" 3. View details of all mobiles available in the shop.");
			System.out.println(" 4. Delete a mobile details based on mobile id.");
			System.out.println(" 5. Search mobiles based on price range.");
			System.out.println(" 6. Write a test case for insert and search mobile service functionalities.");
			System.out.println("Enter your choice.....");
			
			int choice=sc.nextInt();
		switch(choice)
		{
		
		case 1:
			insertdetails();
			break;
        case 2:
			updatemobquantity();
			break;	
			
        case 3:
	        details();
	        break;
		
        case 4:
        	System.out.println("Enter mobileId...");
        	int id=sc.nextInt();
	         delete(id);
	         break;
        case 5:
        	System.out.println("Enter Range of price...");
        	System.out.println("Enter UpperRange of price...");
        	int lr=sc.nextInt();

        	System.out.println("Enter LowerRange of price...");
        	int ur=sc.nextInt();

        	  search(lr,ur);
	         break;
        case 6:
        	  testcase();
	         break;
		default:
			System.exit(0);		
			
		}}
		
		}
		

	

		private static void insertdetails() {
		
		System.out.println("Customer name: ");
        Scanner sc = null;
		String name=sc.next();
        try {
        	if(perchase.validateName(name))
        	{
				System.out.println("Enter mailId: ");
				String mailId=sc.next();
				if(perchase.validateMailId(mailId))
	        	{
				System.out.println("Enter Phone Number: ");
		        String phone=sc.next();
		        if(perchase.validatePhoneNumber(phone))
	        	{
		        System.out.println("Enter mobileId: ");
				String mobileId=sc.next();
				if(perchase.validateMobileId(mobileId))
	        	{
				System.out.println("Enter purchaseId: ");
				String purchaseId=sc.next();
				
		        System.out.println("Enter ur DOB in dd-mm-yyyy ");
		        String strDOB=sc.next();
	        	     }
				
	        	   }
		          }
				 }     
		/**    //    Employee ee=new Employee(eid,enm,esl);
		   //   ee.setEmpDOB(MyStringDateUtil.fromStringToLocalDate(strDOB));
		        
		        int dataAdd=empService.addEmp(ee);
		        if(dataAdd==1)
		        	System.out.println("data Inserted...");
		        else
		        	System.out.println("Some error....");**/
        	}   catch(Exception ee) {
        		System.out.println(ee.getMessage());
        }
	}

	private static void updatemobquantity() {
		
		try {
			perchase.updatemobquantity();
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void details() {
		
		try {
			perchase.details();
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void delete(int id) {
		
		try {
			perchase.delete(id);
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void search(int lr,int ur) {
		
		try {
			perchase.search(lr,ur);
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private static void testcase() {
		
		try {
			perchase.testcase();
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	
}
