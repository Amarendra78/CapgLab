package com.cg.mobile.exception;

public class MobileException extends Exception {


	public MobileException()
	{
		super();
		
	}
	
	public MobileException(String msg) {
		super(msg);
		
	}

	public MobileException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	
	}

	public MobileException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}


	public MobileException(Throwable arg0) {
		super(arg0);
		
	}
	
	
	

}
