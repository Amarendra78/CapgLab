package com.cg.mobile.dao;

import com.cg.mobile.exception.MobileException;

public interface PerchaseDao {
	
	public int insertdetails()throws MobileException;
	public int updatemobquantity()throws MobileException;
	public void details()throws MobileException;
	public int delete(int id)throws MobileException;
	public void search(int lr,int ur)throws MobileException;
	public int testcase()throws MobileException;

}
