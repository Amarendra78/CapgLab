package com.cg.mobile.dao;

import com.cg.mobile.exception.MobileException;

public class PerchaseDaoImpl implements PerchaseDao {

	@Override
	public int insertdetails() throws MobileException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updatemobquantity() throws MobileException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void details() throws MobileException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int delete(int id) throws MobileException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void search(int lr, int ur) throws MobileException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int testcase() throws MobileException {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
