package com.cg.mobile.service;

import com.cg.mobile.dto.*;
import com.cg.mobile.exception.*;

public interface PerchaseDetail {
	
	
	public int insertdetails()throws MobileException;
	public int updatemobquantity()throws MobileException;
	public void details()throws MobileException;
	public int delete(int id)throws MobileException;
	public void search(int lr,int ur)throws MobileException;
	public int testcase()throws MobileException;
	
	public boolean validateName(String empName)throws MobileException;
	public boolean validateMailId(String empMail)throws MobileException;
	public boolean validatePhoneNumber(String empPhone)throws MobileException;
	public boolean validateMobileId(String empMobileId)throws MobileException;
	
	

}
