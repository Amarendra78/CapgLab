package com.cg.mobile.service;

import java.util.regex.Pattern;

import com.cg.mobile.exception.*;
import com.cg.mobile.dao.PerchaseDao;
import com.cg.mobile.dao.PerchaseDaoImpl;
import com.cg.mobile.dao.PerchaseDao;
import com.cg.mobile.dao.PerchaseDaoImpl;
import com.cg.mobile.exception.MobileException;

public class PerchaseDetailImpl implements PerchaseDetail {

	PerchaseDao perDao=null;
	public PerchaseDetailImpl()
	{
		perDao=new PerchaseDaoImpl();
	}
	@Override
	public int insertdetails() throws MobileException {
		
		perDao.insertdetails();
		return 0;
	}

	@Override
	public int updatemobquantity() throws MobileException {
		perDao.updatemobquantity();
		return 0;
	}

	@Override
	public void details() throws MobileException {
		
		perDao.details();
	}

	@Override
	public int delete(int id) throws MobileException {
		
		perDao.delete(id);
		return 0;
	}

	public void search(int lr, int ur) throws MobileException {
		
		perDao.search(lr, ur);
	}

	@Override
	public int testcase() throws MobileException {
		
		perDao.testcase();
		return 0;
	}

	@Override
	public boolean validateName(String Name) throws MobileException {
		String empNamePattern="[A-Z][a-z]{15}";
		if(Pattern.matches(empNamePattern,Name))
		return true;
		else
					throw new MobileException("Invalid name "+"should start with capital");
	}

	@Override
	public boolean validateMailId(String mailId) throws MobileException {
		String empNamePattern="^[a-zA-Z0-9_!#$%&�*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
		if(Pattern.matches(empNamePattern,mailId))
		return true;
		else
					throw new MobileException("Invalid mailId "+"should start with capital");	
	}

	@Override
	public boolean validatePhoneNumber(String phone) throws MobileException {
		String empNamePattern="[9][0-9]{10}+";
		if(Pattern.matches(empNamePattern,phone))
		return true;
		else
					throw new MobileException("Invalid phone "+"should start with capital");	
	}

	@Override
	public boolean validateMobileId(String mobileId) throws MobileException {
		String empNamePattern="[0-9]{4}";
		if(Pattern.matches(empNamePattern,mobileId))
		return true;
		else
					throw new MobileException("mobileId "+"should start with capital");

		
	}
	
	

}
