
public class AccesserMutator {

	
	public boolean flag=false;
	int data;
	public synchronized int getData()
	{
		if(!flag)
		{
			try
			{
				wait();
			}catch(Exception e)
			{
				
			}
		}
		System.out.println("Got : "+data);
		flag=false;
		notify();
		return data;
	}
	
	public synchronized void setData(int data)
	{
		
		if(flag)
		{
			try
			{
				wait();
			}catch(InterruptedException e)
			{
				
			}
		}
		this.data=data;
		System.out.println("set : "+data);
		flag=true;
		notify();
	}
}
