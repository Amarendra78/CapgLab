
public class Account {
	
	public float balance=0.0f;
	public Account(float balance)
	{
		this.balance=balance;
	}
	
	public synchronized void deposite(float depositeAmount)
	{
		
		try {
			float curBalance;
			curBalance=balance;
			System.out.println("Read balance as "+balance+" from "+Thread.currentThread()+"now Adding "+depositeAmount);
			Thread.currentThread().sleep(1000);
			curBalance=curBalance+depositeAmount;
			Thread.currentThread().sleep(1000);
			balance=curBalance;
			System.out.println("Written balance as "+balance+" from "+Thread.currentThread());
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public synchronized void withdraw(float withdrawAmount)
	{
		try {
			float curBalance;
			Thread.currentThread().sleep(1000);
			curBalance=balance;
			System.out.println("Read balance as "+balance+" from "+Thread.currentThread()+"now subtact "+withdrawAmount);
			Thread.currentThread().sleep(1000);
			curBalance=curBalance-withdrawAmount;
			Thread.currentThread().sleep(1000);
			balance=curBalance;
			System.out.println("Written balance as "+balance+" from "+Thread.currentThread());
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}
	

}
