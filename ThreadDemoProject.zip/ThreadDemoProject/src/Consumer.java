
public class Consumer implements Runnable{
	
	AccesserMutator am;
	int limit;
	public Consumer(AccesserMutator am)
	{
		this.am=am;
	//	Thread tc=new Thread(this,"This is consumer");
	//	tc.start();
		
	}
	
	public void run()
	{
		int j=0;
		while(j<10)
		{
			try {
				
				Thread.sleep(1000);
				am.getData();
				j++;
			}catch(InterruptedException ie)
			{
				
				
			}
			
			
		}
		
	}

}
