
public class GreetThread extends Thread{

	
	String msg;
	public GreetThread(String msg)
	{
	this.msg=msg;
	}
	
	public void run()
	{
		for(int i=0;i<=5;i++)
		{
		System.out.println(msg);	
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
						e.printStackTrace();
		}
		}
	}
}
