
public class Producer implements Runnable {

	AccesserMutator am;
	
	public Producer(AccesserMutator am)
	{
		this.am=am;
	}
	public void run()
	{
		int k=0;
		while(k<10)
		{
			k++;
			try {
				Thread.sleep(1000);
				am.setData(k);
				
			}catch(InterruptedException ie)
			{
				
				
			}
			
			
		}
		
	}
	
}
