
public class TestBankOperationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			final boolean withdraw=true,
			deposite=false;
			Account account1=new Account(10000.00f);
			AccountUser user1=new AccountUser(account1,withdraw,3000.00f);
			AccountUser user2=new AccountUser(account1,deposite,2000.00f);
			
			user1.start();
			user2.start();
			
			user1.join();
			user2.join();
			
			System.out.println("final balance is...."+account1.balance);
			}catch(Exception e) {
			e.printStackTrace();			
		}

	}

}
