
public class TestThreadDemo implements Runnable {

	public static void main(String[] args) {
		
		String Threadname=Thread.currentThread().getName();
		System.out.println(Threadname+" Thread Starts here...");
		GreetThread obj1=new GreetThread("Welcome");
		GreetThread obj2=new GreetThread("capg0");
		
		Thread t1=new Thread(obj1);
		Thread t2=new Thread(obj2);
		
		
		
for(int i=0;i<=5;i++)
{
System.out.println("Hello ritika and ujjala");	



try {
	Thread.sleep(500);
} catch (InterruptedException e) {
	
	e.printStackTrace();
}

}

System.out.println("MAin marega yha pe");
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
