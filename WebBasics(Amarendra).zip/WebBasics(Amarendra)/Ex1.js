function Display()
{
var val=document.getElementById("idName").value;
document.getElementById("mydiv").innerHTML = val;
}