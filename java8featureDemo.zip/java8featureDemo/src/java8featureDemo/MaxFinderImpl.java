package java8featureDemo;

public class MaxFinderImpl implements MaxFinder {

	@Override
	public int maximum(int num1, int num2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
