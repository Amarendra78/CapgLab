package java8featureDemo;

import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class TestMaxFinderDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
MaxFinder mf=(num1,num2)->(num1>num2)?num1:num2;
		System.out.println("Greatest no.."+mf.maximum(50, 40));
		
		
		
		
		Consumer<String> consumer=(String str)->System.out.println(str);
		consumer.accept("HELLO LE!");
		
		Supplier<String> supplier=()->"Hello from supplier";
		System.out.println(supplier.get());
		
		Predicate<Integer> predicate=num->num%2==0;
		System.out.println(" Is 24 even no. "+predicate.test(24));
		System.out.println(" Is 15 even no. " +predicate.test(15));
		
		
		BiFunction<Integer,Integer,Integer>maxFunction=(x,y)->x>y?x:y;
		System.out.println(maxFunction.apply(10,20));
	}

}
