package java8featureDemo;

import java.util.*;
import java.util.function.*;
import java.util.stream.Stream;

public class TestStreamApiDemo 
{
	
	public static void main(String[] args) {
	List<Integer> listInt1= Arrays.asList(11,3,44,5,66,33,44);


	listInt1.stream().filter((num)->num>10).forEach(num->System.out.print(" : "+num));
	System.out.println("----------");
	
	long myCount =listInt1.stream().filter((num)->num < 10).count();
	System.out.println(" no of values less than 10 "+myCount);



	List<String> citylist= Arrays.asList("pune","mumbai","banglore","pune","noida");

    citylist.stream().distinct().
    filter((city)->city.length()>0).
    forEach(city->System.out.println(" :"+city));

    long Count =citylist.stream().filter((city)->city.length()==0).count();
	System.out.println(" no of empty String = "+Count);
}}

