let log=function(message)
{
console.log(message);
]
log("welcome ");
*****************************************************
let doLog=(message)=>console.log("welcome arrow");
doLog("welcome using arroe function syntax");
***********************************
let doLog2=()=>console.log("empty msg");
doLog2();
***********************************
function getSum(numOne:number,numTwo:number):number
{
return(numOne+numTwo);
}
console.log(getSum(7,8));
var add=getSum(60,20);
console.log("another result:"+add);
******************************************************
function sumAll(...nums:number[])
{
let sum:number=0;
for(let x of nums)
{
sum=sum+x;
}
console.log("summation ofll numbers:"+sum);
}
sumAll(30,20,10,40);
****************************************************
function doGet(one:number,two=5,three?:number):void
{
console.log("first param:"+one);
console.log("second param:"+two);
console.log("third param:"+three);
}
doGet(10);
doGet(10,20);
doGet(10,20,30);
*****************************************************
