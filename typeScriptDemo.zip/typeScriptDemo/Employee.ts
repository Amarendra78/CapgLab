class Employee
{
empId:number'
empNname:String;
empSal:Number;
static empPF:number=12;
static empComp:String="Capgemini";
}

let e1=new Employee();
e1.empId=112081;
e1.empName="shruthi";
e1.empSal=100000;

console.log("ID :"+e1.empId+"Name: "+e1.empName +"Salary :"+e1.empSal +"PF : "+Employee.empPF +"Company: "+Employee.empComp);
