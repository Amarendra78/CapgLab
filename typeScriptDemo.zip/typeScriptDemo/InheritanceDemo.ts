class Animal
{
constructor(public name:string)
{
}
move(distanceInmeter:number=0)
{
console.log(this.name +"moved"+distanceInmeter);
console.log(`${this.name} moved to ${distanceInmeter}`);
}
}
******************
class Snake extends Animal
{
constructor(public name:string)
{
super(name);
}
move(distanceInmeter:number=5)
{
console.log("Gallopping.........");
super.move(distanceInmeter);
}
}
*************************************
class Horse extends Animal
{
constructor(public name:string)
{
super(name);
}
move(distanceInmeter:number=45)
{
console.log("Gallopping.........");
super.move(distanceInmeter);
}
}
********************************
let sam=new Sname("Python");
let tom:Animal=new Horse("Palomino");
sam.move();
tom.move(80);