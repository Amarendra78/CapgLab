interface IEmployee
{
firstName:String;
lastName:String;
}

let e2:IEmployee=
{
firstName: "shruthi",
lastName :"k u"
}
console.log("Full name:"+this.e2.firstName+"last Name:"+this.e2.lastName);
