
import {IProduct} from",/Product";
import {company} from"./Product";
let prod:IProduct=
{
productId:1001;
productName:"iphone";
}
let productArray:IProduct[]=[
{productId:1002,productName:"lg"},
{productId:1003,productName:"CoolPad"},
{productId:1004,productName:"mi"},
];
console.log(prod.productId);
console.log(prod.productName);
for(let pto of productArray)
{
console.log(prod.productId);
console.log(prod.productName);
}
console.log(company);
