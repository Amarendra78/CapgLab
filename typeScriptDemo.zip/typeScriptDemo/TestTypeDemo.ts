for(let num=1;num<3;num++)
{
console.log("local num:"+num);
}
console.log("---------------");
 
 
 let num1=120;
 if(true)
 {
 let num1=130;
 console.log("Num1="+num1);
 }
 console.log("Num1="+num1);
 