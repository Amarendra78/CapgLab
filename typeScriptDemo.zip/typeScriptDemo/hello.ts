function getData(msg)
{
